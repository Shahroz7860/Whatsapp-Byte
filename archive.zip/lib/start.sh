while true
do
echo "Starting Suhail-Md!"
node .
done